import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
RAW = ROOT / "data" / "raw" / "sample_preview_15114146.csv"


@pytest.fixture(scope="session")
def db_path(tmp_path_factory):
    from etl.build_db import build
    p = tmp_path_factory.mktemp("db") / "test.db"
    build(p, [RAW])
    return p


@pytest.fixture(scope="session")
def con(db_path):
    from app.db import connect
    return connect(db_path)


@pytest.fixture(scope="session")
def rid(con):
    return {r["sigungu"]: r["id"] for r in con.execute("SELECT id, sigungu FROM region")}


@pytest.fixture()
def client(con, monkeypatch):
    from fastapi.testclient import TestClient
    import app.main as m
    m.set_connection(con)
    return TestClient(m.app)
