"""FastAPI 백엔드 — 기능 ② 지역 기준 맞춤 규격 질문 · 실측 보정."""
from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

load_dotenv()

from app.db import connect  # noqa: E402
from app.services import describe, juso  # noqa: E402
from app.services.engine import estimate  # noqa: E402
from etl.normalize import ItemMatcher  # noqa: E402

STATIC = Path(__file__).parent / "static"
app = FastAPI(title="우리동네 대형폐기물 수수료 — 규격 질문·실측 보정 API", version="0.1.0")
app.mount("/static", StaticFiles(directory=STATIC), name="static")

_con = None
_matcher = ItemMatcher()


def con():
    global _con
    if _con is None:
        _con = connect()
    return _con


def set_connection(c):  # 테스트용
    global _con
    _con = c


@app.get("/")
def index():
    return FileResponse(STATIC / "index.html")


@app.get("/api/health")
def health():
    c = con()
    src = [dict(r) for r in c.execute("SELECT kind,name,file_name,ingested_at,row_count FROM data_source")]
    return {"ok": True, "sources": src, "juso_api": bool(os.getenv("JUSO_API_KEY"))}


@app.get("/api/regions")
def regions():
    out: dict[str, list] = {}
    for r in con().execute("SELECT id,sido,sigungu,manager_org FROM region ORDER BY sido,sigungu"):
        out.setdefault(r["sido"], []).append({"id": r["id"], "sigungu": r["sigungu"], "manager_org": r["manager_org"]})
    return [{"sido": k, "sigungu": v} for k, v in out.items()]


@app.get("/api/address")
def address(q: str = Query(..., min_length=1)):
    try:
        rows = juso.search_address(q)
    except juso.JusoError as e:
        raise HTTPException(503, str(e))
    c = con()
    for row in rows:
        reg = juso.resolve_region(c, row["sido"], row["sigungu"])
        row["region_id"] = reg["id"] if reg else None
        row["supported"] = bool(reg)
    return rows


@app.get("/api/items")
def items(region_id: int, q: str = ""):
    c = con()
    if not c.execute("SELECT 1 FROM region WHERE id=?", (region_id,)).fetchone():
        raise HTTPException(404, "지원하지 않는 지역입니다.")
    std = [dict(r) for r in c.execute(
        """SELECT s.code, s.name, s.category, GROUP_CONCAT(li.raw_name, ' / ') AS local_names
           FROM standard_item s JOIN item_mapping m ON m.standard_item_id=s.id
           JOIN local_item li ON li.id=m.local_item_id WHERE li.region_id=?
           GROUP BY s.id ORDER BY s.category, s.name""", (region_id,))]
    unmapped = [dict(r) for r in c.execute(
        """SELECT li.id AS local_item_id, li.raw_name AS name, li.category_raw AS category FROM local_item li
           WHERE li.region_id=? AND li.id NOT IN (SELECT local_item_id FROM item_mapping) ORDER BY li.raw_name""",
        (region_id,))]
    if q.strip():
        codes = set(_matcher.search(q))
        nq = q.replace(" ", "")
        std = [s for s in std if s["code"] in codes or nq in s["name"].replace(" ", "")]
        unmapped = [u for u in unmapped if nq in u["name"].replace(" ", "")]
        if not std and not unmapped:
            raise HTTPException(404, f"'{q}'에 해당하는 품목이 이 지역 수수료표에 없어요. 다른 이름으로 검색하거나 목록에서 골라 주세요.")
    return {"standard": std, "local_only": unmapped}


@app.get("/api/parse")
def parse(text: str = Query(..., min_length=1), region_id: int | None = None):
    """설명 문장 읽기: '폭 180cm 3인용 소파' -> 품목 후보, 치수, 수량. 지역을 주면 그 지역에 있는 품목만 후보로."""
    d = describe.read(text)
    items = d["items"]
    if region_id:
        have = {r[0] for r in con().execute(
            """SELECT DISTINCT s.code FROM standard_item s JOIN item_mapping m ON m.standard_item_id=s.id
               JOIN local_item li ON li.id=m.local_item_id WHERE li.region_id=?""", (region_id,))}
        items = [c for c in items if c in have]
    return {"items": items, "hints": d["hints"], "quantity": d["quantity"], "labels": d["labels"]}


class EstimateIn(BaseModel):
    region_id: int
    standard_code: str | None = None
    local_item_id: int | None = None
    answers: dict = Field(default_factory=dict)


@app.post("/api/estimate")
def post_estimate(body: EstimateIn):
    return estimate(con(), body.region_id, body.standard_code, body.local_item_id, body.answers)


@app.get("/api/compare/{code}")
def compare(code: str):
    """같은 표준 품목의 지역별 규격·수수료 (분석·안내용)."""
    rows = [dict(r) for r in con().execute(
        """SELECT rg.sido, rg.sigungu, li.raw_name, s.raw_spec, f.fee, f.base_date
           FROM standard_item si JOIN item_mapping m ON m.standard_item_id=si.id
           JOIN local_item li ON li.id=m.local_item_id JOIN region rg ON rg.id=li.region_id
           JOIN item_specification s ON s.local_item_id=li.id JOIN disposal_fee f ON f.spec_id=s.id
           WHERE si.code=? ORDER BY rg.sigungu, f.fee""", (code,))]
    if not rows:
        raise HTTPException(404, "해당 표준 품목 데이터가 없습니다.")
    return rows
